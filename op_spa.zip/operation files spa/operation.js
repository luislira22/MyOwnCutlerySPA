import React, { useState, useEffect } from 'react'
import axios from "axios";
import Loading from './Loading'
import OperationTable from './tables/Operation/OperationTable'
import OperationNavBar from './bars/Operation/OperationNavBar'
import CreateOperationForm from './forms/Operation/CreateOperationForm'
import config from '../Config'
import Modal from 'react-bootstrap/Modal';


const Operation = () => {

    const [operations, setOperations] = useState([])
    const [isLoading, setIsLoading] = useState(true)

    const [showCreate, setShowCreate] = useState(false)

    const handleCreateShow = () => setShowCreate(true)
    const handleCreateHide = () => setShowCreate(false)


    const getAllOperations = async () => {
        const allOperations = await axios(config.routes.operations.getAll);
        setOperations(allOperations.data);
        setIsLoading(false);
    }

    const CreateOperation = async operation => {
        const result = {description: operation.description,duration: operation.execTime.hours+":"+operation.execTime.minutes+":"+operation.execTime.seconds,setupTime:operation.setupTime.hours+":"+operation.setupTime.minutes+":"+operation.setupTime.seconds,tool: operation.tool}
        console.log(result)
        await axios({
            method: "post",
            url: config.routes.operations.createOperation,
            data: result,
            headers: { "Content-Type": "application/json;charset=UTF-8" },
        }).catch((error) => {
            console.log(error)
        })
        getAllOperations();
    }

    useEffect(() => {
        getAllOperations()
    }, []);

    return (
        <div className="container">

            <h1>Operation</h1>
            {isLoading ?
                <Loading />
                : (
                    <>
                        <OperationNavBar
                            reload={getAllOperations}
                            showCreate={handleCreateShow}
                        />
                        <OperationTable
                            operations={operations}
                        />
                        <Modal
                            show={showCreate}
                            onHide={handleCreateHide}
                            size="lg"
                            aria-labelledby="contained-modal-title-vcenter"
                            centered>
                            <Modal.Body>
                                <CreateOperationForm
                                    createOperation={CreateOperation}
                                    hideCreate={handleCreateHide} />
                            </Modal.Body>
                        </Modal>
                    </>
                )}
        </div>
    )
}

export default Operation
